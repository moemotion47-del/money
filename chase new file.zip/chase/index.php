<script>
    window.location = 'business.php'
</script>