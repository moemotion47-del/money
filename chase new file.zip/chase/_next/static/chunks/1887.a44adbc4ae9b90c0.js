"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[1887],{40731:function(n,e,r){r.d(e,{t:function(){return a}});var o=r(85893),i=r(68458),t=r(23206);let d=i.ZP.picture.withConfig({componentId:"sc-48d530b9-0"})(["",";img{",";}"],t.eD,n=>n.$isExactHeight&&"display: block");function a(n){let{src:e,defaultSrc:r,alt:i,className:a,height:l,width:m,borderRadius:c,dataTestId:g,displayExactHeight:u=!1}=n;return(0,o.jsxs)(d,{$isExactHeight:u,children:[e?.map((n,e)=>o.jsx("source",{srcSet:n.srcSet,media:n.media},e)),(0,o.jsx)(t.Ee,{borderRadius:c,src:r,alt:i,className:a,height:l,width:m,dataTestId:g})]})}},41887:function(n,e,r){r.r(e),r.d(e,{default:function(){return B}});var o=r(85893),i=r(22969),t=r(64755),d=r(80037),a=r(5860),l=r(23206),m=r(73378),c=r(4615),g=r(61849),u=r(68458),s=r(38019),p=r(40731),w=r(67294);function h(n){return"primary"===n||!n}let $=(0,u.ZP)(t.Aq).withConfig({componentId:"sc-3a5bd946-0"})(["border-bottom-right-radius:",";grid-row-start:2;grid-row-end:5;grid-column-start:1;grid-column-end:2;@media (min-width:","){grid-row-start:3;grid-row-end:5;grid-column-start:1;grid-column-end:5;}"],n=>n.$backgroundRoundEdgeBottom?"var(--border-radius-large)":"0",s.A.large),b=(0,u.ZP)(g.A).withConfig({componentId:"sc-3a5bd946-1"})([""," padding-top:1rem;padding-left:1rem;padding-right:1rem;grid-row-start:3;grid-row-end:4;grid-column-start:1;grid-column-end:2;@media (min-width:","){padding-top:0;"," "," grid-column-start:",";"," ","}"],n=>`
       color: var(--media-block-text-color${n.$backgroundContainerColorSuffix});
       a {
         color: var(--media-block-link-text-color${n.$backgroundContainerColorSuffix});
         }
       a:focus, a:active {
           outline: var(--media-block-text-color${n.$backgroundContainerColorSuffix}) var(--link-outline-style) var(--link-outline-size);
        }
    `,s.A.large,n=>!h(n.$backgroundContainerColor)&&n?.$layoutAlignment==="right"&&`
      padding-top: 3rem;
      padding-right: 0;
      padding-left: 3.5rem;
      grid-column-start: 1;
      grid-column-end: 2;
    `,n=>!h(n.$backgroundContainerColor)&&n?.$layoutAlignment==="left"&&`
      padding-top: 3rem;
      padding-left: 0;
      padding-right: 3.5rem;
      grid-column-start: 4;
      grid-column-end: 5;
    `,n=>n?.$layoutAlignment==="right"?"1":"4",n=>h(n.$backgroundContainerColor)&&n?.$layoutAlignment==="left"&&`
        padding-right: 0;
        padding-left: 0;
        grid-row-start: 2;
        grid-row-end: 3;
        grid-column-start: 4;
        grid-column-end: 5;
    `,n=>h(n.$backgroundContainerColor)&&n?.$layoutAlignment==="right"&&`
      padding-right: 0;
      padding-left: 0;
      grid-row-start: 2;
      grid-row-end: 3;
      grid-column-start: 1;
      grid-column-end: 3;
    `),C=(n,e)=>e?.filter(e=>e.type===n)[0]?.isDark,k=u.ZP.div.withConfig({componentId:"sc-3a5bd946-2"})([""," padding-left:1rem;padding-right:1rem;grid-row-start:4;grid-row-end:5;grid-column-start:1;grid-column-end:2;",";",";@media (min-width:","){",";",";",";",";",";",";}"],n=>`
       color: var(--media-block-text-color${n.$backgroundContainerColorSuffix});
       a {
         color: var(--media-block-link-text-color${n.$backgroundContainerColorSuffix});
         }
       a:focus, a:active {
           outline: var(--media-block-text-color${n.$backgroundContainerColorSuffix}) var(--link-outline-style) var(--link-outline-size);
        }
        ${C(n.$backgroundContainerColor,n.theme.legacy?.backgroundOptions)?`.link {&:hover {
          color: var(--media-block-link-text-color${n.$backgroundContainerColorSuffix});
        }}`:`.link-inverse {&:hover {
          color: var(--link-hover-color);
        }}`}
    `,n=>!n?.$mediaBlockTitle&&`
      padding-top: 1rem;
  `,n=>!h(n.$backgroundContainerColor)&&`
    padding-bottom: 5rem;
  `,s.A.large,n=>!n?.title&&`
        padding-top: 3rem;
    `,n=>!h(n.$backgroundContainerColor)&&n?.$layoutAlignment==="right"&&`
      padding-right: 0;
      padding-left: 3.5rem;
      grid-row-start: 4;
      grid-row-end: 5;
      grid-column-start: 1;
      grid-column-end: 2;
    `,n=>!h(n.$backgroundContainerColor)&&n?.$layoutAlignment==="left"&&`
      padding-left: 0;
      padding-right: 3.5rem;
      grid-row-start: 4;
      grid-row-end: 5;
      grid-column-start: 4;
      grid-column-end: 5;
    `,n=>h(n.$backgroundContainerColor)&&`
      padding-right: 0;
      padding-left: 0;
      grid-row-start: 3;
      grid-row-end: 4;
  `,n=>h(n.$backgroundContainerColor)&&n?.$layoutAlignment==="left"&&`
      grid-column-start: 4;
      grid-column-end: 5;
  `,n=>h(n.$backgroundContainerColor)&&n?.$layoutAlignment==="right"&&`
      grid-column-start: 1;
      grid-column-end: 2;
  `),f=u.ZP.div.withConfig({componentId:"sc-3a5bd946-3"})(["grid-row-start:1;grid-row-end:3;grid-column-start:1;display:grid;grid-template-rows:[startRowLine] auto [endRowLine];grid-template-columns:[startColumnLine] auto [endColumnLine];",";@media (min-width:","){",";",";",";",";}"],n=>n?.$decorativeIcon&&`
  grid-template-rows: [startRowLine] 48px [rowLine2] auto [endRowLine];
  grid-template-columns: [startColumnLine] auto [endColumnLine];

  @media (min-width: ${s.A.small}) {
    grid-template-rows: [startRowLine] 78px [rowLine2] auto [endRowLine];
    grid-template-columns: [startColumnLine] auto [endColumnLine];
  }

  @media (min-width: ${s.A.large}) {
    grid-template-rows: [startRowLine] 78px [rowLine2] auto [endRowLine];
    grid-template-columns: [startColumnLine] auto [endColumnLine];
  }
  `,s.A.large,n=>h(n.$backgroundContainerColor)&&`
      grid-row-end: 4;
    `,n=>!h(n.$backgroundContainerColor)&&`
      grid-row-end: 5;
      margin-bottom: 5rem;
    `,n=>n?.$layoutAlignment==="right"&&`
      grid-column-start: 3;
      grid-column-end: 5;
    `,n=>n?.$layoutAlignment==="left"&&`
      grid-column-start: 1;
      grid-column-end: 3;
    `),v=u.ZP.div.withConfig({componentId:"sc-3a5bd946-4"})(["height:fit-content;",";",";",";",";"],n=>!n?.$decorativeIcon&&`
    grid-row-start: 1;
    grid-row-end: 2;
    grid-column-start: 1;
    grid-column-end: 2;
    `,n=>n?.$decorativeIcon&&n?.$decorativeIconAlignment==="right"&&`
    grid-column-start: 1;
    grid-column-end: 3;
    @media (min-width: ${s.A.large}) {
      grid-row-start: 2;
      grid-row-end: 3;
      grid-column-start: 1;
      grid-column-end: 2;
    }
  `,n=>n?.$decorativeIcon&&n?.$decorativeIconAlignment==="left"&&`
    grid-column-start: 1;
    grid-column-end: 3;
    @media (min-width: ${s.A.large}) {
      grid-row-start: 2;
      grid-row-end: 3;
      grid-column-start: 2;
      grid-column-end: 3;
    }
  `,n=>n.$isVideo&&`
    padding-right: 0;
    background-color: unset;
  `),x=u.ZP.div.withConfig({componentId:"sc-3a5bd946-5"})(["width:2rem;height:2rem;@media (min-width:","){width:3.875rem;height:3.875rem;}grid-row-start:1;grid-row-end:2;"," ",""],s.A.small,n=>n?.$decorativeIconAlignment==="right"&&`
    grid-column-start: 2;
    grid-column-end: 3;
  `,n=>n?.$decorativeIconAlignment==="left"&&`
    grid-column-start: 1;
    grid-column-end: 2;
  `),L=(0,u.ZP)(a.Jn).withConfig({componentId:"sc-3a5bd946-6"})(["grid-template-rows:[startRowLine] auto [rowLine2] 40px [rowLine3] auto [rowLine4] auto [endRowLine];grid-template-columns:[startColumnLine] 100% [endColumnLine];",";",";"," ",";@media (min-width:","){"," ",";",";}"],n=>!h(n.$backgroundContainerColor)&&!n?.$decorativeIcon&&`
    @media (min-width: ${s.A.large}) {
        grid-template-rows: [startRowLine] 40px [rowLine2] auto [rowLine3] 1fr [endRowLine];
        grid-template-columns: [startColumnLine] 40% [columnLine2] 10% [columnLine3] 10% [columnLine4] 40% [endColumnLine];
    }`,n=>!h(n.$backgroundContainerColor)&&n?.$decorativeIcon&&n?.$mediaBlockTitle&&`
    @media (min-width: ${s.A.large}) {
        grid-template-rows: [startRowLine] 78px [rowLine2] 40px [rowLine3] auto [rowLine4] 1fr [endRowLine];
        grid-template-columns: [startColumnLine] 40% [columnLine2] 10% [columnLine3] 10% [columnLine4] 40% [endColumnLine];
    }`,n=>!h(n.$backgroundContainerColor)&&n?.$decorativeIcon&&!n?.$mediaBlockTitle&&`
    @media (min-width: ${s.A.large}) {
        grid-template-rows: [startRowLine] 78px [rowLine2] 40px [rowLine3] 1fr [endRowLine];
        grid-template-columns: [startColumnLine] 40% [columnLine2] 10% [columnLine3] 10% [columnLine4] 40% [endColumnLine];
    }`,n=>h(n.$backgroundContainerColor)&&`
    @media (min-width: ${s.A.large}) {
      grid-template-rows: [startRowLine] 40px [rowLine2] auto [rowLine3] 100% [endRowLine];
      grid-template-columns: [startColumnLine] 40% [columnLine2] 10% [columnLine3] 10% [columnLine4] 40% [endColumnLine];
    }`,s.A.xxlarge,n=>n.$isSubModule&&n.$featuredVideo&&"--video-container-min-width: 25.0625rem;",n=>n.$isSubModule&&n.$featuredVideo&&"right"===n.$layoutAlignment&&n.$decorativeIcon&&`--video-container-min-width: 21.0625rem;
      `,n=>n.$isSubModule&&n.$featuredVideo&&"left"===n.$layoutAlignment&&n.$decorativeIcon&&`--video-container-min-width: 22.0625rem;
        `),A=u.ZP.div.withConfig({componentId:"sc-3a5bd946-7"})(["display:inline-block;",";",";",";",";"],n=>"left"===n.$addBrandBarToImage&&`
    border-left: 1.25rem solid var(--media-block-media-bg);
    `,n=>("right"===n.$addBrandBarToImage||n.$applyRightImageBorder)&&`
      padding-right: 1.25rem;
      background-color: var(--media-block-media-bg);
    `,n=>"bottom"===n.$addBrandBarToImage&&`
      padding-bottom: 1.25rem;
      background-color: var(--media-block-media-bg);
    `,n=>"top"===n.$addBrandBarToImage&&`
      border-top: 1.25rem solid var(--media-block-media-bg);
    `),y=(0,u.ZP)(p.t).withConfig({componentId:"sc-3a5bd946-8"})(["vertical-align:bottom;"]),I=u.ZP.div.withConfig({componentId:"sc-3a5bd946-9"})(["color:var(--cta-tertiary-color);width:100%;padding-left:1rem;padding-right:1rem;padding-top:1.5rem;padding-bottom:2.5rem;margin-top:0;margin-bottom:0;button{margin-bottom:4rem;}@media (min-width:","){padding-bottom:1rem;margin-top:0;margin-bottom:0;button{display:inline-block;}}@media (min-width:","){padding-top:2rem;}@media (min-width:","){padding-left:0;button{margin-bottom:0;}}"],s.A.xsmall,s.A.small,s.A.large),j=n=>{let{backgroundContainerColor:e="primary",decorativeIcon:r,featuredImage:i,featuredImageAltText:t,decorativeIconAlignment:d,decorativeIconAltText:u,title:p,bodyText:w,layoutAlignment:h,links:C,featuredVideo:j,applyRightImageBorder:B=!1,addBrandBarToImage:S="none",imageRoundEdgeBottom:T=!0,backgroundRoundEdgeBottom:P=!0,isSubModule:Z=!1}=n,N=function(n){switch(n){case"secondary":return"-secondary";case"neutral":return"-neutral";case"theme_bg_dark":return"-dark";case"theme_bg_light":return"-light";default:return"-primary"}}(e),_=i?[{srcSet:i?.mega,media:`(min-width: ${s.A.large})`},{srcSet:i?.desktop,media:`(min-width: ${s.A.medium})`},{srcSet:i?.tablet,media:`(min-width: ${s.A.xsmall})`},{srcSet:i?.mobile}]:[],E=(0,o.jsxs)(f,{$decorativeIcon:r,$layoutAlignment:h,$backgroundContainerColor:e,children:[(0,o.jsxs)(v,{$decorativeIcon:r,$decorativeIconAlignment:d,$isVideo:!!j,children:[j&&(0,o.jsx)(c.N5,{...j.values,applyRightImageBorder:B,backgroundContainerColor:e,render:n=>n.playVideo&&n.player&&(0,o.jsx)(I,{children:(0,o.jsx)(m.u,{...n,player:n.player})})}),i&&(0,o.jsx)(A,{$addBrandBarToImage:S,$applyRightImageBorder:B,children:(0,o.jsx)(y,{src:_,defaultSrc:i.mega,alt:t||"",borderRadius:T})})]}),r&&(0,o.jsx)(x,{$decorativeIconAlignment:d,children:(0,o.jsx)(l.ct,{src:r,alt:u})})]});return(0,o.jsx)(a.T5,{"data-feature":"media-block",children:(0,o.jsx)(a.Jn,{children:(0,o.jsx)(a.C4,{col:"12",children:(0,o.jsx)(a.Jn,{className:"mds-jc-center",noGutters:!0,children:(0,o.jsx)(a.C4,{col:"12",colAt768:"10",children:(0,o.jsx)(L,{$backgroundContainerColor:e,$decorativeIcon:r,$mediaBlockTitle:p,className:"mds-d-grid h-100 mds-overflow-hidden",noGutters:!0,$isSubModule:Z,$layoutAlignment:h,$featuredVideo:!!j,children:p?(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)($,{$backgroundRoundEdgeBottom:P,color:e||"primary"}),(0,o.jsx)(b,{content:p,$layoutAlignment:h,$backgroundContainerColor:e,$backgroundContainerColorSuffix:N}),E,(0,o.jsxs)(k,{$mediaBlockTitle:p,$layoutAlignment:h,$backgroundContainerColor:e,$backgroundContainerColorSuffix:N,children:[(0,o.jsx)(g.A,{className:"mds-pb-at-576-6_7 mds-pb-6",content:w}),C&&C.length>0?(0,o.jsx)(R,{links:C}):null]})]}):(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)($,{$backgroundRoundEdgeBottom:P,color:e||"primary"}),(0,o.jsxs)(k,{$mediaBlockTitle:p,$layoutAlignment:h,$backgroundContainerColor:e,$backgroundContainerColorSuffix:N,children:[(0,o.jsx)(g.A,{className:"mds-pb-at-576-6_7 mds-pb-6",content:w}),C&&C.length>0?(0,o.jsx)(R,{links:C}):null]}),E]})})})})})})})},R=n=>{let{links:e}=n;return(0,o.jsx)("div",{className:"mds-d-flex mds-jc-flex-start mds-fd-row mds-pb-1",children:e?.map((n,e)=>o.jsx(w.Fragment,{children:o.jsx(d.RL,{linkOpenIn:n?.values?.linkOpenIn,href:n?.values?.url,type:n?.values?.linkPresentationType,trackingId:n?.values?.trackingId,trackingType:n?.values?.linkTrackingType,accessibleText:n?.values?.linkAccessibleText,showSpeedBump:n?.values?.showSpeedBump,linkIcon:n?.values?.linkIcon,linkIconPosition:n?.values?.linkIconPosition,className:"mds-mr-5",width:"no-min-width",inverse:n?.values?.inverse,disabled:n?.values?.disabled,overlayType:n?.values?.overlayType,children:n?.values?.linkText},e)},e))})};function B(n){let{key:e,...r}=n;return(0,o.jsx)(i.S,{name:"MediaBlockContainer",children:(0,o.jsx)(j,{...r})},e)}}}]);