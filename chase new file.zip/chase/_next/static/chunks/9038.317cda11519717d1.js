"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[9038],{35417:function(n,e,d){d.d(e,{Z:function(){return s}});var t=d(85893),i=d(64755),r=d(5860),a=d(68458),o=d(38019);let m={large:`
      padding-bottom: 5rem;
      @media (max-width: ${o.A.small}) {
        padding-bottom: 2.5rem;
      }
    `,medium:`
      padding-bottom: 2.5rem;
      @media (max-width: ${o.A.small}) {
        padding-bottom: 1.5rem;
      }
    `,small:`
      padding-bottom: 1.5rem;
      @media (max-width: ${o.A.small}) {
        padding-bottom: 1rem;
      }
    `},l=(0,a.ZP)(i.df).withConfig({componentId:"sc-123a63d5-0"})(["",""],n=>m[n.$size]);function s(n){let{color:e="primary",size:d="small",roundedBorder:a="none",fullWidthOn:o=!1}=n,m=(0,t.jsx)(r.T5,{"data-feature":"padding",children:(0,t.jsx)(r.Jn,{children:(0,t.jsx)(r.C4,{col:"12",children:(0,t.jsx)(l,{$roundedCorner:a,color:e,$size:d})})})});return o?(0,t.jsx)(i.Aq,{color:e,children:m}):m}},29038:function(n,e,d){d.r(e),d.d(e,{default:function(){return a}});var t=d(85893),i=d(22969),r=d(35417);function a(n){let{key:e,...d}=n;return(0,t.jsx)(i.S,{name:"PaddingContainer",children:(0,t.jsx)(r.Z,{...d})},e)}}}]);